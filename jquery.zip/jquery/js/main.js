function myClick(){
	//document.getElementById("example").innerHTML="hi";

}
$(document).ready(function(){
	/*$(".list-element").each(function(key,val){
	    console.log(val);
	    $(this).text($(this).text()+" added by js");
	});*/
});

