let sum=(a) => (b) => b ? sum(a+b): a; 
console.log("sum= "+sum(1)(2)());

let multiply = (a) => (a>0) ? ( multiply(a-1)+321 ) : ( a < 0 ? multiply( a+1 )-321 : 0 ); 
console.log("multiply= "+multiply(-3));

let sumRange = (a) => (a>0) ? (sumRange(a-1)+a)  : 0;
console.log("sumRange= "+sumRange (5));

let power = (a,b) => (b>0) ? (power (a,b-1)*a) : 1; 
console.log("power= "+power (2,5));

let factorial = (a) => (a>1) ? (factorial(a-1)*a) : 1;
console.log("factorial= "+factorial (5));

var arrayMultiply =(a,b) =>{
	if(a>0){
		if(typeof myArray !== 'undefined'){
			myArray.push(b);
			return arrayMultiply(a-1,b);
		}
		else{
			myArray=[];
			return arrayMultiply(a,b);
		}
	}else{
		return myArray;
	}
	
}
console.log("arrayMultiply= ["+arrayMultiply(4,3)+"]");