$(document).ready(function() {
	// $("button").click(function() {
	// 	console.log ( $ (this).attr("name") == "submit" ? "submit clicked" 
	// 		: ( $ (this).attr("name")== "clear" ? "clear clicked" : "another clicked" )  )
	// 	 // ($(this).attr("name")=="submit") ? (console.log("submit clicked")) :( ($(this).attr("name")=="clear") ? (console.log("clear clicked")): (($(this).attr("name")=="another") ? (console.log("another clicked")) : console.log("something clicked")) );
	// });

	$("button").on("click",(function(event) {
		event.preventDefault();
		console.log("The clicked button is: "+
				(
					( $(this).attr("name") == "submit" ? 
						( 
							$(this).attr("id") == "submit" ? "submit clicked" : "not real button"
						):
						(
							$(this).attr("name") == "clear" ? "clear" : "something else"
						)
					)
				)
		);
	}));
});