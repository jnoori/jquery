var currentNumber="";
$(document).ready(function(){
    $(".showScreen").on('click',function(){
        $("#screen").append($(this).val());
        $("#screen").val($("#screen").text());    
    });
    $(".equal").on('click',function(){
        try {
            var result = eval($("#screen").val());
            $("#screen").html(eval($("#screen").val()));
        }
        catch (e) {
            alert("Please insert valid expression");
            $("#screen").html("");
            $("#screen").val("");
        }
    });
    $(".clear").on('click',function(){
        $("#screen").html("");
        $("#screen").val("");
    });
    $(".backSpace").on('click',function(){
        var exp=$("#screen").text();
        $("#screen").html(exp.substring(0,exp.length-1));
        $("#screen").val(exp); 
    });
});