var currentNumber="";
var result;
var operator;
var operand;
$(document).ready(function(){
	$("button").on('click',function(){
    	var id= $(this).attr('id');
    	switch(id){
    		case "1": case "2": case "3":
    		case "4": case "5": case "6":
    		case "7": case "8": case "9":
    		currentNumber+=id;
    		$("#screen").html(currentNumber);
    		break;

    		case "plus":
    			operator = "+"
    			operand = parseFloat(currentNumber);
    			currentNumber = "";
    			$("#screen").html("");
    			break;
    		case "minus":
    			operator = "-"
    			operand = parseFloat(currentNumber);
    			currentNumber = "";
    			$("#screen").html("");
    			break;
    		case "multi":
    			operator = "*"
    			operand = parseFloat(currentNumber);
    			currentNumber = "";
    			$("#screen").html("");
    			break;
    		case "divide":
    			operator = "/"
    			operand = parseFloat(currentNumber);
    			currentNumber = "";
    			$("#screen").html("");
    			break;
    		case "equal":
    			switch(operator){
    				case "+":
    					result = operand + parseFloat(currentNumber);
						$("#screen").html(result);
						break;
					case "-":
    					result = operand - parseFloat(currentNumber);
						$("#screen").html(result);
						break;
					case "*":
    					result = operand * parseFloat(currentNumber);
						$("#screen").html(result);
						break;
					case "/":
						if(parseFloat(currentNumber) != 0){
							result = operand / parseFloat(currentNumber);
							$("#screen").html(result);
							break;
						}
    			}
    	}
	});
});