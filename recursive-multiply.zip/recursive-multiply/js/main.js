$(document).ready(function(){
	var multiply = (i) =>{
	if(i > 0){
	  //For positive numbers
	  return multiply(i-1)+321;       
	}
	else if(i < 0){
	  //For Negative numbers
	  return multiply(i+1)-321;
	}
	else{
	  //For 0
	  return 0;
	}
	return multiply(i);
	}
	console.log(multiply(0));
});

