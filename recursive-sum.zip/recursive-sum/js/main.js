// $(document).ready(function(){
// 	var multiply = (i) =>{
// 	if(i > 0){
// 	  //For positive numbers
// 	  return multiply(i-1)+321;       
// 	}
// 	else if(i < 0){
// 	  //For Negative numbers
// 	  return multiply(i+1)-321;
// 	}
// 	else{
// 	  //For 0
// 	  return 0;
// 	}
// 	return multiply(i);
// 	}
// 	console.log(multiply(1));
// });

/*function mySum(a) {
  var sum = a;
  function f(b) {
    sum += b;
    return f;  //<- from second call, f is returned each time
              //   so you can chain those calls indefinitely
              //   function sum basically got "overridden" by f
  }
  f.toString = function() { return sum; }
  return f; //<- after first call, f is returned
}
console.log(mySum(6)(-1)(-2)(-3));*/

/*function mySum(a) {
	var result=a;
	var i=1;
	console.log("res1="+result);
	function f(b) {
		result+=b;
		console.log("res2="+result);
		if(i==1){
			i--;
			console.log("i2="+i);
			return f;
		}else{
			console.log("res4="+result);
			return result;
		}
	}
	console.log("i1="+i);
	 return f;
}
console.log(mySum(6));
console.log(mySum(6)(-1)(-2));
*/

/*function sum(a){ return function(b){return b ?  sum(a+b):a};

}*/

let sum=(a) => (b) => b ? sum(a+b): a; 
console.log("sum= "+sum(1)(2)());

let multiply = (a) => (a>0) ? ( multiply(a-1)+321 ) : ( a < 0 ? multiply( a+1 )-321 : 0 ); 
console.log("multiply= "+multiply(-3));

let sumRange = (a) => (a>0) ? (sumRange(a-1)+a)  : 0;
console.log("sumRange= "+sumRange (5));

let power = (a,b) => (b>0) ? (power (a,b-1)*a) : 1;
console.log("power= "+power (2,5));

let factorial = (a) => (a>1) ? (factorial(a-1)*a) : 1;
console.log("factorial= "+factorial (5));

let arrayMultiply= function(a,b){
	let myArray=[];
	if(b>0){
		return myArray.push(arrayMultiply(a,b-1));
	}else{
		myArray.push(a);
		return myArray;
	}
}
let arr= arrayMultiply (2,3);
for(i in arr){
	console.log("arrayMultiply= "+arr[i]+", ");
}