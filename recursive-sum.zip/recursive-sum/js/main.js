// $(document).ready(function(){
// 	var multiply = (i) =>{
// 	if(i > 0){
// 	  //For positive numbers
// 	  return multiply(i-1)+321;       
// 	}
// 	else if(i < 0){
// 	  //For Negative numbers
// 	  return multiply(i+1)-321;
// 	}
// 	else{
// 	  //For 0
// 	  return 0;
// 	}
// 	return multiply(i);
// 	}
// 	console.log(multiply(1));
// });

function mySum(a) {
  var sum = a;
  function f(b) {
    sum += b;
    return f;  //<- from second call, f is returned each time
              //   so you can chain those calls indefinitely
              //   function sum basically got "overridden" by f
  }
  f.toString = function() { return sum; }
  return f; //<- after first call, f is returned
}
console.log(mySum(6)(-1)(-2)(-3));

// function mySum(a) {
// 	var result=a;
// 	var i=1;
// 	console.log("res1="+result);
// 	function f(b) {
// 		result+=b;
// 		console.log("res2="+result);
// 		if(i==1){
// 			i--;
// 			console.log("i2="+i);
// 			return f;
// 		}else{
// 			console.log("res4="+result);
// 			return result;
// 		}
// 	}
// 	//f.toString=function(){return result};
// 	//console.log("res3="+f.toString());
// 	console.log("i1="+i);
// 	 return f;
// }
// console.log(mySum(6));
//console.log(mySum(6)(-1)(-2));
