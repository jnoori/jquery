var currentNumber="";
var result;
$(document).ready(function(){
    $(".showScreen").on('click',function(){
        $("#screen").append($(this).val());
        $("#screen").val($("#screen").text());    
    });
    $(".equal").on('click',function(){
        try {
            var result = eval($("#screen").val());
            $("#screen").html(eval($("#screen").val()));
        }
        catch (e) {
            $('#screen').html('invalid Expression');
            $("#screen").html("");
            $("#screen").val("");
            alert("Please insert valid expression");
        }
        $("#screen").html(eval($("#screen").val()));
    });
    $(".clear").on('click',function(){
        $("#screen").html("");
        $("#screen").val("");
    });
    $(".backSpace").on('click',function(){
        var exp=$("#screen").text();
        $("#screen").html(exp.substring(0,exp.length-1));
        $("#screen").val(exp); 
    });
});