$(document).ready(function() {
    /****************** variables  ***************/
    var playerTurn = "p1"; //p1 -> color1, p2 -> color2
    var arrayBlock = [
                        [0, 0, 0],
                        [0, 0, 0],
                        [0, 0, 0]
                    ]; // 0->empty, 1->color1, 2->color2
    endGame = false;
    moveComplete=false;
    var blockId;
    /****************** variables  ***************/

    /*************************** Start of general functions  ************************/
    /****************** Start of listing moves function ***************/
    var checkMove= (moves,p) =>{
        for(i=0; i<arrayBlock.length; i++){
            for(j=0; j<arrayBlock[i].length; j++){
                if(arrayBlock[i][j] == 1 && p==1){
                    moves+="["+i+","+j+"]</br>";
                }
                if(arrayBlock[i][j] == 2 && p==2){
                    moves+="["+i+","+j+"]</br>";
                }
            }                       
        } 
        return moves;
    }
    /****************** End of listing moves function ***************/

    /****************** Start of checkWin function ***************/
    var checkWin = () => { // 0-> nothing, 1->p1, 2->p2, 3->draw
        checkDraw = 0; // if there is no empty blocks and no one win its draw
        for (i = 0; i < arrayBlock.length; i++) {
            if (arrayBlock[i][0] == 0) { // check if any blocks still empty
                checkDraw++;
            } else {
                if ((arrayBlock[i][0] == arrayBlock[i][1]) 
                    && (arrayBlock[i][0] == arrayBlock[i][2])) { // check if a row of blocks equal
                    endGame = true;
                    if (arrayBlock[i][0] == 1) {
                        alert("player 1 is winner");
                        return 1;
                    } else {
                        alert("player 1 is winner");
                        return 2;
                    }
                }
            }
        }
        for (i = 0; i < arrayBlock.length; i++) {
            if (arrayBlock[0][i] == 0) {
                checkDraw++;
            } else {
                if ((arrayBlock[0][i] == arrayBlock[1][i]) 
                    && (arrayBlock[1][i] == arrayBlock[2][i])) {// check if a col of blocks equal
                    endGame = true;
                    if (arrayBlock[0][i] == 1) {
                        alert("player 1 is winner");
                        return 1;
                    } else {
                        alert("player 2 is winner");
                        return 2;
                    }
                }
            }
        }
        if ((((arrayBlock[0][0] == arrayBlock[1][1]) 
            && (arrayBlock[1][1] == arrayBlock[2][2]))&&arrayBlock[1][1] != 0)
             ||
            (((arrayBlock[0][2] == arrayBlock[1][1]) 
            && (arrayBlock[1][1] == arrayBlock[2][0]))&&arrayBlock[1][1] != 0))
            {// check if a diognal of blocks equal
            endGame = true;
            if (arrayBlock[1][1] == 1) {
                alert("player 1 is winner");
                return 1;
            } else {
                alert("player 2 is winner");
                return 2;
            }
        }
        if (checkDraw == 0) {
            endGame = true;
            alert("draw");
            return 3;
        }
        return 0;
    }
    /****************** End of checkWin function ***************/
    /**********************End of general functions  *********************/

    /****************** Start of hover function ***************/
    $(".block").hover(function() {
        /* Stuff to do when the mouse enters the element */
        if(!endGame && !moveComplete){
            if ($(this).hasClass('defaultColor')) {
                $(this).removeClass('defaultColor');
                if (playerTurn == "p1") {
                    $(this).addClass('color1');
                } else {
                    $(this).addClass('color2');
                }
            }
        }      
    }, function() {
        /* Stuff to do when the mouse leaves the element */
        if(!endGame && !moveComplete){
            if ($(this).attr('value') == "0") {
                $(this).hasClass('color1') ? $(this).removeClass('color1') 
                                            : $(this).removeClass('color2');
                $(this).addClass('defaultColor');
            }
        } 
    });
    /****************** End of hover function ***************/

    /****************** Start of click on block function ***************/
    $(".block").on('click', function(event) {
        var p1Moves="";
        var p2Moves="";
        moveComplete = true;
        if(!endGame){
            if ($(this).attr('value') == "0") {
                if ($(this).hasClass('color1')) {
                    blockId=$(this).attr('id');

                    /**********************************************
                    row -> id/3 and it should be integer or rounded
                    col -> id%3 
                    because the array has 3 row and 3 col
                    *********************************************/
                    arrayBlock[parseInt((blockId) / 3)][blockId % 3] = 1;
                    $(this).attr('value', '1');
                    checkWin();
                    playerTurn = "p2";
                    $(".undo-p2").addClass('hidden');
                    $(".undo-p1").removeClass('hidden');
                    /********** listing the Moves **********/
                    p1Moves=checkMove(p1Moves,1);  
                    $(".p1Moves").html(p1Moves); 
                    /********** listing the Moves **********/      
                }
                if ($(this).hasClass('color2')) {
                    blockId=$(this).attr('id');
                    arrayBlock[parseInt((blockId) / 3)][blockId % 3] = 2;
                    $(this).attr('value', '2');
                    checkWin();
                    playerTurn = "p1";
                    $(".undo-p1").addClass('hidden');
                    $(".undo-p2").removeClass('hidden');
                    /********** listing the Moves **********/
                    p2Moves=checkMove(p2Moves,2);   
                    $(".p2Moves").html(p2Moves);   
                    /********** listing the Moves **********/              
                }
            }
        }
    });
    /****************** End of click on block function ***************/

    /****************** Start of undo function ***************/ 
    $(".undo-p1").on('click', function(event) {
        var p1Moves="";
        moveComplete=false;
        if (!endGame) {
            arrayBlock[parseInt((blockId) / 3)][blockId % 3] = 0;
            $("#"+blockId).attr('value', '0');
            $(".undo-p1").addClass('hidden');
            $("#"+blockId).removeClass('color1');
            $("#"+blockId).addClass('defaultColor');
            playerTurn = "p1";
            p1Moves=checkMove(p1Moves,1);  
            $(".p1Moves").html(p1Moves);
        }      
    });
    $(".undo-p2").on('click', function(event) {
        var p2Moves="";
        moveComplete=false;
        if (!endGame) {
            arrayBlock[parseInt((blockId) / 3)][blockId % 3] = 0;
            $("#"+blockId).attr('value', '0');
            $(".undo-p2").addClass('hidden');
            $("#"+blockId).removeClass('color2');
            $("#"+blockId).addClass('defaultColor');
            playerTurn = "p2";
            p2Moves=checkMove(p2Moves,2);  
            $(".p2Moves").html(p2Moves);
        }
    });
    /****************** End of undo function ***************/ 

    $(".moveComplete").on('click', function(event) {
        moveComplete=false;
    });
});