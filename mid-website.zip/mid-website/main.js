$(document).ready(function () {
    $(".item").hover(function () {
        // over
        $(this).css("font-size", "20px");
    }, function () {
        // out
        $(this).css("font-size", "16px");
    });
    $(function () {
        $('.slider').bxSlider({
            mode: 'fade',
            captions: true,
            slideWidth: 600
        });
    });

    /* Form Validation */
    // Name, last name, Email can't be blank
    $('#fname, #lname, #email, #phone').on('input', function () {
        var input = $(this);
        var is_name = input.val();
        if (is_name) {
            input.removeClass("invalid").addClass("valid");
        } else {
            input.removeClass("valid").addClass("invalid");
        }
    });
    // After Form Submitted Validation
    $("#contact_submit").click(function (event) {
        var form_data = $("#contact").serializeArray();
        var error_free = true;
        for (var input in form_data) {
            var element = $("#" + form_data[input]['name']);
            var valid = element.hasClass("valid");
            var error_element = $("span", element.parent());
            if (!valid) {
                error_element.removeClass("error").addClass("error_show");
                error_free = false;
            } else {
                error_element.removeClass("error_show").addClass("error");
            }
        }
        if (!error_free) {
            event.preventDefault();
        } else {
            alert('No errors: Form will be submitted');
        }
    });

    // show or hide footer
    $(".show_footer").click(function () {
        $(".footer").toggle();
    });
});